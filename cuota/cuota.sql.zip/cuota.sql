-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost:3316:3316
-- 生成日時: 2021-05-13 11:18:28
-- サーバのバージョン： 10.4.17-MariaDB
-- PHP のバージョン: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `cuota`
--
CREATE DATABASE IF NOT EXISTS `cuota` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cuota`;

-- --------------------------------------------------------

--
-- テーブルの構造 `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL COMMENT '記事ID',
  `user_id` varchar(60) NOT NULL COMMENT 'ユーザーID',
  `category_id` varchar(60) NOT NULL COMMENT 'カテゴリーID',
  `title` varchar(60) NOT NULL COMMENT 'タイトル',
  `comment` varchar(60) NOT NULL COMMENT 'コメント',
  `evaluation` int(11) DEFAULT 0 COMMENT '評価数',
  `url` varchar(60) DEFAULT NULL COMMENT 'URL',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '投稿日時'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- テーブルのデータのダンプ `article`
--

INSERT INTO `article` (`id`, `user_id`, `category_id`, `title`, `comment`, `evaluation`, `url`, `created_at`) VALUES
(8, '1', '3', 'java', 'java\r\njava', 1, 'java', '2021-05-11 00:33:25'),
(9, '1', '4', 'DB', 'DB\r\nDB', 0, 'DB', '2021-03-25 23:57:48'),
(10, '1', '5', 'PHP', 'PHP\r\nPHP', 0, 'PHP', '2021-03-25 23:59:36'),
(13, '26', '2', 'CSS', 'CSS　CSS\r\nCSS', 2, '', '2021-04-07 09:15:35'),
(14, '1', '4', 'DB2', 'DB2\r\nDB2\r\n', 0, 'https://proengineer.internous.co.jp/content/columnfeature/64', '2021-04-08 05:46:54'),
(15, '1', '3', 'javascript3', 'javascript3', 0, 'https://www.kagoya.jp/howto/webhomepage/javascript/', '2021-04-08 05:59:37'),
(16, '1', '2', 'CSSプロパティ', 'CSSのプロパティがカテゴリー別に整理されていて、\r\n調べたいものが見つけやすい。', 2, 'http://www.htmq.com/csskihon/001.shtml', '2021-05-11 07:33:58'),
(18, '36', '3', 'jQuery', 'jQuery', 1, 'https://www.pasonatech.co.jp/workstyle/column/detail.html?p=', '2021-04-13 03:46:11'),
(20, '1', '3', 'aaaaaaa', 'ssssssssssss', 1, 'https://techacademy.jp/magazine/23824', '2021-04-13 07:40:44'),
(21, '38', '4', 'SQL文', 'SQL文について', 1, 'https://qiita.com/Hailee/items/136439b53a1c4a8265b3', '2021-05-08 08:10:53');

-- --------------------------------------------------------

--
-- テーブルの構造 `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL COMMENT 'カテゴリーID',
  `name` varchar(20) NOT NULL COMMENT 'カテゴリー名'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- テーブルのデータのダンプ `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'HTML'),
(2, 'CSS'),
(3, 'javascript/jQuery'),
(4, 'DB'),
(5, 'PHP'),
(6, 'その他');

-- --------------------------------------------------------

--
-- テーブルの構造 `good`
--

CREATE TABLE `good` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `user_id` int(11) NOT NULL COMMENT 'ユーザーID',
  `article_id` int(11) NOT NULL COMMENT '記事ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- テーブルのデータのダンプ `good`
--

INSERT INTO `good` (`id`, `user_id`, `article_id`) VALUES
(65, 1, 13),
(84, 1, 6),
(86, 1, 7),
(97, 1, 18),
(98, 1, 17),
(103, 1, 20),
(106, 38, 21),
(108, 38, 16),
(109, 1, 8),
(112, 1, 16);

-- --------------------------------------------------------

--
-- テーブルの構造 `keep`
--

CREATE TABLE `keep` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- テーブルのデータのダンプ `keep`
--

INSERT INTO `keep` (`id`, `user_id`, `article_id`) VALUES
(2, 26, 12),
(11, 1, 6),
(12, 1, 7),
(17, 1, 17),
(21, 38, 21),
(22, 38, 16),
(23, 1, 8),
(28, 1, 10),
(34, 1, 16);

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL COMMENT 'ユーザーID',
  `name` varchar(20) NOT NULL COMMENT 'ユーザーネーム',
  `email` varchar(60) NOT NULL COMMENT 'メールアドレス',
  `password` varchar(100) NOT NULL COMMENT 'パスワード'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, '藤川潤市', 'juuuun.03690@ezweb.ne.jp', '$2y$10$szHjuXAIFJcxH.hM6aKJ.egEFS.wkel5o0RfL4vrQ02TqTwy46rVW'),
(18, 'フジカワジュンイチ', 'aaa@aaa', '$2y$10$lQrjuukth8czIyXu0E7S.eSq3Z7zPFM69miBqpnmg20SPhVUWYGuS'),
(26, 'やまだ', 'rrr@rrr', '$2y$10$hUor5efV0F..obpQVU1vpuJJUHgefsSHH4zBuG582HgufPav.apSC'),
(31, 'いとだ', 'bbb@bbb', '$2y$10$iNVFltlwUy5KkZFN8IGDauXx.FlPa5yqWKkY4VRNqqMhakUbYCEOi'),
(36, 'テスト太郎', 'iii@iii', '$2y$10$sTbX3q4/2nls11V2HHKbBeml979MBWkPiT0i5HFrSFVaemA1XLGY6'),
(37, '管理者', 'admin@admin', '$2y$10$vh1fwhYGBHxvPwHGw/BVq.WHzQV.S7s1G.mdWTPYvUqXoyc9K7c2a'),
(38, 'なかた', 'www@www', '$2y$10$rEaxVZ1B7tcD5847eCKsDuQzgbSJTdRgHaVIQStJcIoqJVcc4zyFe');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `good`
--
ALTER TABLE `good`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `keep`
--
ALTER TABLE `keep`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `name` (`name`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '記事ID', AUTO_INCREMENT=23;

--
-- テーブルの AUTO_INCREMENT `good`
--
ALTER TABLE `good`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID', AUTO_INCREMENT=113;

--
-- テーブルの AUTO_INCREMENT `keep`
--
ALTER TABLE `keep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ユーザーID', AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
